<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produto;


class ProdutosController extends Controller
{
     public function index(){
 	$produtos = Produto::paginate(6);

   	return view('produtos.index', ['produtos'=>$produtos
   ]);

   }
   public function show (Request $request){
	$idProduto=$request->id;

	$produto=Produto::where('id_produto', $idProduto)->with('produtos')->first();

	return view('produtos.show',  ['produto'=>$produto]);
}

	public function create() {


    return view ('produtos.create');
}

public function store(Request $request){

    $novoProduto=$request -> validate ([
                
               'designacao'=>['nullable','min:3','max:20'],
               'stock'=>['nullable','min:3','max:20'],
               'preco'=>['nullable','min:3','max:20'],
               'id_categoria'=>['nullable','min:3','max:20']


              
    ]);

$produtos=Produto::create($novoProduto);
    return redirect()->route('produtos.show',['id'=>$produtos->id_produto]);
}


}
