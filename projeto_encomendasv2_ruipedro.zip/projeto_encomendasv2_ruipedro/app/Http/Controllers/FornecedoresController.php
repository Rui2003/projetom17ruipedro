<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Fornecedor;


class FornecedoresController extends Controller
{
     public function index(){
 	$fornecedores = Fornecedor::paginate(14);

   	return view('fornecedores.index', ['fornecedores'=>$fornecedores
   ]);

   }
   public function show (Request $request){
	$idFornecedor=$request->id;
	$fornecedor=Fornecedor::where('id_fornecedor', $idFornecedor)->with('vendedores')->first();
	return view('fornecedores.show',  ['fornecedor'=>$fornecedor]);
}
public function create() {


    return view ('fornecedores.create');
}

public function store(Request $request){

    $novoFornecedor=$request -> validate ([
                
               'designacao'=>['nullable','min:3','max:20']
              
    ]);

$fornecedores=Fornecedor::create($novoFornecedor);
    return redirect()->route('fornecedores.show',['id'=>$fornecedores->id_fornecedor]);
}


public function edit (Request $request){
    $idFornecedor = $request->id;

    $fornecedor = Fornecedor::where('id_fornecedor',$idFornecedor)->first();
    return view('fornecedores.edit',[
'fornecedor'=>$fornecedor
    ]);
}
public function update (Request $request){
    $idFornecedor = $request->id;
    $fornecedor = Fornecedor::findOrFail($idFornecedor);

    $atualizarFornecedor = $request->validate ([
        'id_fornecedor'=>['numeric','nullable'],
'nome'=>['required','min:3','max:100'],
'morada'=>['required','min:3','max:100'],
'id_categoria'=>['numeric','nullable'],
'telefone'=>['numeric','nullable']
    ]);

$fornecedor->update($atualizarFornecedor);

return redirect()->route('fornecedores.show',[
'id'=>$fornecedor->id_fornecedor
]);

}
public function delete (Request $request){
    $idFornecedor = $request->id;
    $fornecedor = Fornecedor::where('id_fornecedor',$idFornecedor)->first();

    return view('fornecedores.delete',[
'fornecedor'=>$fornecedor
    ]);
}
public function destroy (Request $request){
    $idFornecedor = $request->id;

    $fornecedor = Fornecedor::findOrFail($idFornecedor);

    $fornecedor->delete();

return redirect()->route('fornecedores.index')
->with('mensagem','Fornecedor eliminado');


  }
}



