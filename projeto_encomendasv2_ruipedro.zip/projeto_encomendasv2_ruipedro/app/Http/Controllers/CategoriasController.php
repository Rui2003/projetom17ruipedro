<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categoria;


class CategoriasController extends Controller
{
     public function index(){
 	$categorias = Categoria::paginate(14);

   	return view('categorias.index', ['categorias'=>$categorias
   ]);

   }

   public function show (Request $request){
	$idCategoria=$request->id;
	$categoria=Categoria::where('id_categoria', $idCategoria)->with('produtos')->first();
	return view('categorias.show',  ['categoria'=>$categoria]);
}

	public function create() {


    return view ('categorias.create');
}

public function store(Request $request){

    $novoCategoria=$request -> validate ([
                
               'designacao'=>['nullable','min:3','max:20']
              
    ]);

$categorias=Categoria::create($novoCategoria);
    return redirect()->route('categorias.show',['id'=>$categorias->id_categoria]);
}

public function delete (Request $request){
    $idCategoria = $request->id;
    $categoria = Categoria::where('id_categoria',$idCategoria)->first();

    return view('categorias.delete',[
'categoria'=>$categoria
    ]);
}
public function destroy (Request $request){
    $idCategoria = $request->id;

    $categoria = Categoria::findOrFail($idCategoria);

    $categoria->delete();

return redirect()->route('categorias.index')
->with('mensagem','Categoria eliminada');


  }
  public function edit (Request $request){
    $idCategoria = $request->id;

    $categoria = Categoria::where('id_categoria',$idCategoria)->first();
    return view('categorias.edit',[
'categoria'=>$categoria
    ]);
}
public function update (Request $request){
    $idCategoria = $request->id;
    $categoria = Categoria::findOrFail($idCategoria);

    $atualizarCategoria = $request->validate ([
        'id_categoria'=>['numeric','nullable'],
'designacao'=>['required','min:3','max:100']
    ]);

$categoria->update($atualizarCategoria);

return redirect()->route('categorias.show',[
'id'=>$categoria->id_categoria
]);

}
}

