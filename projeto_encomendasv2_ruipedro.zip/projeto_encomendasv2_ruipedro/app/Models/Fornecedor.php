<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fornecedor extends Model
{
    use HasFactory;
    protected $primaryKey="id_fornecedor";

    protected $table="fornecedores";

    public function vendedores(){
        return $this->hasMany('App\Models\Vendedor', 'id_vendedor');
    }

    public function categorias(){
        return $this->hasMany('App\Models\Categoria', 'id_categoria');
    }
protected $fillable=[
    'id_fornecedor',
    'nome',
    'morada',
    'id_categoria',
    'telefone'

   ];
}

