<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/categorias', 'App\Http\Controllers\CategoriasController@index')->name('categorias.index');

Route::get('/fornecedores', 'App\Http\Controllers\FornecedoresController@index')->name('fornecedores.index');

Route::get('/produtos', 'App\Http\Controllers\ProdutosController@index')->name('produtos.index');

Route::get('/vendedores', 'App\Http\Controllers\VendedoresController@index')->name('vendedores.index');

Route::get('/categorias/{id}/show', 'App\Http\Controllers\CategoriasController@show')->name('categorias.show');

Route::get('/produtos/{id}/show', 'App\Http\Controllers\ProdutosController@show')->name('produtos.show');

Route::get('/fornecedores/{id}/show', 'App\Http\Controllers\FornecedoresController@show')->name('fornecedores.show');

Route::get('/vendedores/{id}/show', 'App\Http\Controllers\VendedoresController@show')->name('vendedores.show');

Route::get('/categorias/create', 'App\Http\Controllers\CategoriasController@create')
->name('categorias.create');

Route::post('/categorias', 'App\Http\Controllers\CategoriasController@store')
->name('categorias.store');

Route::get('/categorias/{id}/delete', 'App\Http\Controllers\CategoriasController@delete')
->name('categorias.delete');

Route::delete('/categorias', 'App\Http\Controllers\CategoriasController@destroy')
->name('categorias.destroy');
Auth::routes();

Route::get('/categorias/{id}/edit', 'App\Http\Controllers\CategoriasController@edit')
->name('categorias.edit');

Route::patch('/categorias', 'App\Http\Controllers\CategoriasController@update')
->name('categorias.update');

Route::get('/fornecedores/create', 'App\Http\Controllers\FornecedoresController@create')
->name('fornecedores.create');

Route::post('/fornecedores', 'App\Http\Controllers\FornecedoresController@store')
->name('fornecedores.store');

Route::get('/fornecedores/{id}/delete', 'App\Http\Controllers\FornecedoresController@delete')
->name('fornecedores.delete');

Route::delete('/fornecedores', 'App\Http\Controllers\FornecedoresController@destroy')
->name('fornecedores.destroy');
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/fornecedores/{id}/edit', 'App\Http\Controllers\FornecedoresController@edit')
->name('fornecedores.edit');

Route::patch('/fornecedores', 'App\Http\Controllers\FornecedoresController@update')
->name('fornecedores.update');

Route::get('/produtos/create', 'App\Http\Controllers\ProdutosController@create')
->name('produtos.create');

Route::post('/produtos', 'App\Http\Controllers\ProdutosController@store')
->name('produtos.store');
