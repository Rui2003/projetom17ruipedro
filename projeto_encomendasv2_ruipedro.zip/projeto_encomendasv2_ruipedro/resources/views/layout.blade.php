<!DOCTYPE html>
@yield('inicio')
<html>

<head>

 @yield('css')
<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">
<script src="{{asset('js/jquery-3.5.1.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/bootstrap.min.js')}}" type="text/javascript"></script>
   @yield('img')
      
</head>

<body>

@yield('nav')
    <nav  class="navbar navbar-expand-md navbar-blue fixed-top bg-dark" >
<a class="navbar-brand" >PSI-Encomendas v2</a>
<button class="navbar-toggler" type="button" data-toggler="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation" >
    <span class="navbar-toggler-icon" ></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExampleDefault" >
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link active" href="{{route('categorias.index')}}">Categorias</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="{{route('fornecedores.index')}}">Fornecedores</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="{{route('produtos.index')}}">Produtos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="{{route('vendedores.index')}}">Vendedores</a>
        </li>
            </li>
        </ul>
    </div>
</nav>


@yield('final')

<p align="center"><img src="img.jpg" width="1000" height="500">



<hr>
    </div> <!--/container-->
</main> 
<footer class="container">
 
</footer>
</body>
</html>
