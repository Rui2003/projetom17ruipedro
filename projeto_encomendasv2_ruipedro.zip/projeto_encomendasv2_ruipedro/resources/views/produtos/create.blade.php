<!DOCTYPE html>
<html>
<head>
    <title>Formulário</title>
</head>
<body>
    <form action="{{route('produtos.store')}}" method="post">
@csrf
id_categoria: <input type="text" name="id_categoria" value="{{old('id_categoria')}}"><br>

designacao:  <input type="text" name="designacao"value="{{old('designacao')}}"><br>

stock:  <input type="text" name="stock"value="{{old('stock')}}"><br>

preco:  <input type="text" name="preco"value="{{old('preco')}}"><br>

observacoes:  <input type="text" name="observacoes"value="{{old('observacoes')}}"><br>


<input type="submit" value="Enviar">
</form>



</body>
</html>