@extends('layout')
@section('nav')
@endsection
<br><br><br>
@section('final')
<ul>
@foreach($produtos as $produto)
<u>
<a href="{{route('produtos.show', ['id'=>$produto->id_produto])}}">
	{{$produto->designacao}}</a></u>

	<br>
@endforeach
</ul>
{{$produtos->render()}}




@endsection
<br><a href="{{route('produtos.create' , ['id' =>$produto ->id_produto])}}"><b>Criar</b></a><br>
