ID - <u><b>{{$produto->id_produto}}<br></u></b>
Designação - <b><u>{{$produto->designacao}}<br></u></b>
Preço - <b><u>{{$produto->preco}}<br></u></b>
Stock - <b><u>{{$produto->stock}}<br></u></b>


<h3>Fornecedores</h3>
@foreach($produto->fornecedores as $fornecedor)
<b><u>{{$fornecedor->nome}}<br></b></u>
<b><u>{{$fornecedor->telefone}}<br></b></u>
<b><u>{{$fornecedor->morada}}<br></b></u>
@endforeach

