<h3>Categorias</h3>
@foreach($categoria->produtos as $produto)
<u>{{$produto->designacao}}</u>
<br>	
@endforeach

Designação - <u><b>{{$categoria->designacao}}<br></u></b>
ID - <u><b>{{$categoria->id_categoria}}<br></u></b>

<br><a href="{{route('categorias.edit' , ['id' =>$categoria ->id_categoria])}}"><b>Editar</b></a><br>

<br><a href="{{route('categorias.delete' , ['id' =>$categoria ->id_categoria])}}"><b>Eliminar</b></a><br>