@if(session()->has('mensagem'))
<div class="alert alert-danger"role="alert">
    {{session('mensagem')}}
</div>
@endif
<h2>Deseja eliminar a categoria</h2>
<h2>{{$categoria->id_categoria}}
    {{$categoria->designacao}}</h2>
    <form method="post" action="{{route('categorias.destroy', ['id'=>$categoria->id_categoria])}}">
        @csrf
        @method('delete')
        <input type="submit" value="enviar">
</form>