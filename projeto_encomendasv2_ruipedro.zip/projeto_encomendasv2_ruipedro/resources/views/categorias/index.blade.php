@extends('layout')
@section('nav')
@endsection
<br><br><br>
@section('final')
<ul>
@foreach($categorias as $categoria)
<u>
<a href="{{route('categorias.show', ['id'=>$categoria->id_categoria])}}">
	{{$categoria->designacao}}</a></u>
	<br>
@endforeach
</ul>
{{$categorias->render()}}

@endsection

<br><a href="{{route('categorias.create' , ['id' =>$categoria ->id_categoria])}}"><b>Criar</b></a><br>

