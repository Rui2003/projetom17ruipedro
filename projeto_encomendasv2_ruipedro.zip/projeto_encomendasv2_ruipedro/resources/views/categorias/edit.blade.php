<form action="{{route('categorias.update', ['id'=>$categoria->id_categoria])}}" method="post">
@csrf
@method('patch')
ID:<input type="text" name="id_categoria" value="{{$categoria->id_categoria}}"><br>
Designação:<input type="text" name="designacao" value="{{$categoria->designacao}}"><br>


<input type="submit" name="enviar">
</form>

</form>