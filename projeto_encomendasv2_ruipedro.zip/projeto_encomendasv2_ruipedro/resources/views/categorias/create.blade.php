<form action="{{route('categorias.store')}}" method="post">
    @csrf


Designação:<input type="text" name="designacao"><br>


<input type="submit" name="enviar">
</form>
