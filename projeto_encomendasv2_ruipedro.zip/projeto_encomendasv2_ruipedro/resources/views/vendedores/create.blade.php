<!DOCTYPE html>
<html>
<head>
    <title>Formulário</title>
</head>
<body>
    <form action="{{route('encomendas.store')}}" method="post">
@csrf
id_categoria: <input type="text" name="id_categoria" value="{{old('id_categoria')}}"><br>

designacao:  <input type="text" name="designacao"value="{{old('designacao')}}"><br>


<input type="submit" value="Enviar">
</form>



</body>
</html>