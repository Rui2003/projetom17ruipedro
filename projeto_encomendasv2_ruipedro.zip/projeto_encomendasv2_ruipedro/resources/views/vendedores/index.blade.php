@extends('layout')
@section('nav')
@endsection
<br><br><br>
@section('final')<ul>
@foreach($vendedores as $vendedor)<u>
<a href="{{route('vendedores.show', ['id'=>$vendedor->id_vendedor])}}">
	{{$vendedor->nome}}</a><br></u>
@endforeach
</ul>
{{$vendedores->render()}}
@endsection
<b><a href="#">Criar</a></b>
