Nome - <u><b>{{$vendedor->nome}}<br></u></b>
ID - <b><u>{{$vendedor->id_vendedor}}<br></u></b>
Especialidade - <b><u>{{$vendedor->especialidade}}<br></u></b>
Email - <b><u>{{$vendedor->email}}</u></b>

<h3>Produtos</h3>
@foreach($vendedor->produtos as $produto)
<u>{{$produto->designacao}}</u>
<h3>Stock</h3>
{{$produto->stock}}
<h3>Preço</h3>
{{$produto->preco}}
@endforeach

