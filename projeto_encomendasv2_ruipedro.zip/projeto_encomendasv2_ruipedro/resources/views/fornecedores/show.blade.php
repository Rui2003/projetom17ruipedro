ID:{{$fornecedor->id_fornecedor}}<br>
Nome:{{$fornecedor->nome}}<br>
ID:{{$fornecedor->id_categoria}}<br>
Morada:{{$fornecedor->morada}}<br>
Telefone:{{$fornecedor->telefone}}

<h2>Vendedores</h2>
@foreach($fornecedor->vendedores as $vendedor)
<li>{{$vendedor->nome}}</li>
<li>{{$vendedor->especialidade}}</li>
<li>{{$vendedor->email}}</li>
@endforeach

<h2>Categoria</h2>
@foreach($fornecedor->categorias as $categoria)
<li>{{$categoria->designacao}}</li>
<br><a href="{{route('fornecedores.edit' , ['id' => $fornecedor ->id_fornecedor])}}"><b>Editar</b></a>


<br><a href="{{route('fornecedores.delete' , ['id' => $fornecedor ->id_fornecedor])}}"><b>Eliminar</b></a><br>

<br>
<br>
@endforeach



