@extends('layout')
@section('nav')
@endsection
<br><br><br>
@section('final')
<ul>
@foreach($fornecedores as $fornecedor)
<u>
<a href="{{route('fornecedores.show', ['id'=>$fornecedor->id_fornecedor])}}">
	{{$fornecedor->nome}}</a></u>
	<br>
@endforeach
</ul>
{{$fornecedores->render()}}




@endsection
<br><a href="{{route('fornecedores.create' , ['id' =>$fornecedor ->id_fornecedor])}}"><b>Criar</b></a><br>
