@if(session()->has('mensagem'))
<div class="alert alert-danger"role="alert">
    {{session('mensagem')}}
</div>
@endif
<h2>Deseja eliminar os fornecedores </h2>
<h2>{{$fornecedor->id_fornecedor}}
    {{$fornecedor->nome}}
    {{$fornecedor->morada}}
    {{$fornecedor->id_categoria}}
    {{$fornecedor->telefone}}
</h2>
    <form method="post" action="{{route('fornecedores.destroy', ['id'=>$fornecedor->id_fornecedor])}}">
        @csrf
        @method('delete')
        <input type="submit" value="enviar">
</form>