<form action="{{route('fornecedores.store')}}" method="post">
    @csrf

Nome:<input type="text" name="nome"><br><br>
Morada:<input type="text" name="morada"><br><br>
id_categoria:<input type="text" name="id_categoria"><br><br>
Telefone:<input type="text" name="telefone"><br><br>


<input type="submit" name="enviar">
</form>