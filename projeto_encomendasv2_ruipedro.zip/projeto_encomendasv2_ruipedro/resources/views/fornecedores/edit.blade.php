<form action="{{route('fornecedores.update', ['id'=>$fornecedor->id_fornecedor])}}" method="post">
@csrf
@method('patch')

Nome:<input type="text" name="nome"><br><br>
Morada:<input type="text" name="morada"><br><br>

Telefone:<input type="text" name="telefone"><br><br>

<input type="submit" name="enviar">
</form>

</form>