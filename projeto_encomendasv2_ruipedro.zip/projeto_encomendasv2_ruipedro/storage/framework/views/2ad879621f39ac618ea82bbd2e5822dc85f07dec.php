<form action="<?php echo e(route('fornecedores.update', ['id'=>$fornecedor->id_fornecedor])); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>

Nome:<input type="text" name="nome"><br><br>
Morada:<input type="text" name="morada"><br><br>

Telefone:<input type="text" name="telefone"><br><br>

<input type="submit" name="enviar">
</form>

</form><?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/fornecedores/edit.blade.php ENDPATH**/ ?>