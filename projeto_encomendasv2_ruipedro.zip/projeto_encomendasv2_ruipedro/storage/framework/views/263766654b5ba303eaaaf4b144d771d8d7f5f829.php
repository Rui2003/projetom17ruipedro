<h3>Categorias</h3>
<?php $__currentLoopData = $categoria->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u><?php echo e($produto->designacao); ?></u>
<br>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

Designação - <u><b><?php echo e($categoria->designacao); ?><br></u></b>
ID - <u><b><?php echo e($categoria->id_categoria); ?><br></u></b>

<br><a href="<?php echo e(route('categorias.edit' , ['id' =>$categoria ->id_categoria])); ?>"><b>Editar</b></a><br>

<br><a href="<?php echo e(route('categorias.delete' , ['id' =>$categoria ->id_categoria])); ?>"><b>Eliminar</b></a><br><?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/categorias/show.blade.php ENDPATH**/ ?>