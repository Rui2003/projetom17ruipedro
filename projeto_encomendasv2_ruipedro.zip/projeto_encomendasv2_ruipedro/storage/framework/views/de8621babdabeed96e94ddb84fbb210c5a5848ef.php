<ul>
<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('categorias.show', ['id'=>$categoria->id_categoria])); ?>">
	<?php echo e($categoria->designacao); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($categorias->render()); ?><?php /**PATH C:\Users\anton\Desktop\Projeto_PSI_Rafael\resources\views/categorias/index.blade.php ENDPATH**/ ?>