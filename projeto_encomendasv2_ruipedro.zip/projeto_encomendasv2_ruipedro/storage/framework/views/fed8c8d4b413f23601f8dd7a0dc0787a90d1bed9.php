<form action="<?php echo e(route('categorias.update', ['id'=>$categoria->id_categoria])); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>
ID:<input type="text" name="id_categoria" value="<?php echo e($categoria->id_categoria); ?>"><br>
Designação:<input type="text" name="designacao" value="<?php echo e($categoria->designacao); ?>"><br>


<input type="submit" name="enviar">
</form>

</form><?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/categorias/edit.blade.php ENDPATH**/ ?>