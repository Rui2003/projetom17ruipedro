<form action="<?php echo e(route('fornecedores.store')); ?>" method="post">
    <?php echo csrf_field(); ?>

Nome:<input type="text" name="nome"><br><br>
Morada:<input type="text" name="morada"><br><br>
id_categoria:<input type="text" name="id_categoria"><br><br>
Telefone:<input type="text" name="telefone"><br><br>


<input type="submit" name="enviar">
</form><?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/fornecedores/create.blade.php ENDPATH**/ ?>