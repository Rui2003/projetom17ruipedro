
<?php $__env->startSection('nav'); ?>
<?php $__env->stopSection(); ?>
<br><br><br>
<?php $__env->startSection('final'); ?>
<ul>
<?php $__currentLoopData = $fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u>
<a href="<?php echo e(route('fornecedores.show', ['id'=>$fornecedor->id_fornecedor])); ?>">
	<?php echo e($fornecedor->nome); ?></a></u>
	<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($fornecedores->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trabalhospsi\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/fornecedores/index.blade.php ENDPATH**/ ?>