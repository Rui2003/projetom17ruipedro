Nome:<?php echo e($vendedor->nome); ?><br>
ID:<?php echo e($vendedor->id_vendedor); ?><br>
Especialidade:<?php echo e($vendedor->especialidade); ?><br>
Email:<?php echo e($vendedor->email); ?>


<h2>Produtos</h2>
<?php $__currentLoopData = $vendedor->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u><?php echo e($produto->designacao); ?></u>
<h2>Stock</h2>
<u><?php echo e($produto->stock); ?></u>
<h2>Preço</h2>
<u><?php echo e($produto->preco); ?></u>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\rpedr\OneDrive\Desktop\Projeto_PSI_Rafael\resources\views/vendedores/show.blade.php ENDPATH**/ ?>