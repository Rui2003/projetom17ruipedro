ID:<?php echo e($categoria->id_categoria); ?><br>
Designacao:<?php echo e($categoria->designacao); ?><br>

<h2>Produtos</h2>
<?php $__currentLoopData = $categoria->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($produto->designacao); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\anton\Desktop\PSI-Projeto-Rafael\resources\views/categorias/show.blade.php ENDPATH**/ ?>