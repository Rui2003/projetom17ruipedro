<h3>Produtos</h3>
<?php $__currentLoopData = $categoria->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u><?php echo e($produto->designacao); ?></u>
<br>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

Designação - <u><b><?php echo e($categoria->designacao); ?><br></u></b>
ID - <u><b><?php echo e($categoria->id_categoria); ?><br></u></b>

<?php /**PATH D:\trabalhospsi\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/categorias/show.blade.php ENDPATH**/ ?>