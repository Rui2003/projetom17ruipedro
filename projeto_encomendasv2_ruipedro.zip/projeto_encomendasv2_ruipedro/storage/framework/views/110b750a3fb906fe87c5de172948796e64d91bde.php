<ul>
<?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('produtos.show', ['id'=>$produto->id_produto])); ?>">
	<?php echo e($produto->designacao); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($produtos->render()); ?><?php /**PATH C:\Users\anton\Desktop\PSI-Projeto-Rafael\resources\views/produtos/index.blade.php ENDPATH**/ ?>