Nome - <u><b><?php echo e($vendedor->nome); ?><br></u></b>
ID - <b><u><?php echo e($vendedor->id_vendedor); ?><br></u></b>
Especialidade - <b><u><?php echo e($vendedor->especialidade); ?><br></u></b>
Email - <b><u><?php echo e($vendedor->email); ?></u></b>

<h3>Produtos</h3>
<?php $__currentLoopData = $vendedor->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u><?php echo e($produto->designacao); ?></u>
<h3>Stock</h3>
<?php echo e($produto->stock); ?>

<h3>Preço</h3>
<?php echo e($produto->preco); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/vendedores/show.blade.php ENDPATH**/ ?>