ID:<?php echo e($produto->id_produto); ?><br>
Designação:<?php echo e($produto->designacao); ?><br>
Stock:<?php echo e($produto->stock); ?><br>
Preço:<?php echo e($produto->preco); ?>


<h2>Fornecedores</h2>
<?php $__currentLoopData = $produto->fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($fornecedor->nome); ?></li>
<li><?php echo e($fornecedor->morada); ?></li>
<li><?php echo e($fornecedor->telefone); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\anton\Desktop\PSI-Projeto-Rafael\resources\views/produtos/show.blade.php ENDPATH**/ ?>