
<?php $__env->startSection('nav'); ?>
<?php $__env->stopSection(); ?>
<br><br><br>
<?php $__env->startSection('final'); ?>
<ul>
<?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u>
<a href="<?php echo e(route('produtos.show', ['id'=>$produto->id_produto])); ?>">
	<?php echo e($produto->designacao); ?></a></u>

	<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($produtos->render()); ?>





<?php $__env->stopSection(); ?>
<br><a href="<?php echo e(route('produtos.create' , ['id' =>$produto ->id_produto])); ?>"><b>Criar</b></a><br>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/produtos/index.blade.php ENDPATH**/ ?>