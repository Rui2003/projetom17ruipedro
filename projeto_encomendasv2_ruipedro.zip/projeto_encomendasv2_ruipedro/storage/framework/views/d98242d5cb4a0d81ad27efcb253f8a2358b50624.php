<form action="<?php echo e(route('categorias.store')); ?>" method="post">
    <?php echo csrf_field(); ?>


Designação:<input type="text" name="designacao"><br>


<input type="submit" name="enviar">
</form>
<?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/categorias/create.blade.php ENDPATH**/ ?>