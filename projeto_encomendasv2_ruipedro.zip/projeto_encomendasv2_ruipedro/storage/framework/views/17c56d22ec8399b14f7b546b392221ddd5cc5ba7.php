<?php if(session()->has('mensagem')): ?>
<div class="alert alert-danger"role="alert">
    <?php echo e(session('mensagem')); ?>

</div>
<?php endif; ?>
<h2>Deseja eliminar a categoria</h2>
<h2><?php echo e($categoria->id_categoria); ?>

    <?php echo e($categoria->designacao); ?></h2>
    <form method="post" action="<?php echo e(route('categorias.destroy', ['id'=>$categoria->id_categoria])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <input type="submit" value="enviar">
</form><?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/categorias/delete.blade.php ENDPATH**/ ?>