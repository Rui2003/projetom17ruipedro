<ul>
<?php $__currentLoopData = $vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('vendedores.show', ['id'=>$vendedor->id_vendedor])); ?>">
	<?php echo e($vendedor->nome); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($vendedores->render()); ?><?php /**PATH C:\Users\anton\Desktop\Projeto_PSI_Rafael\resources\views/vendedores/index.blade.php ENDPATH**/ ?>