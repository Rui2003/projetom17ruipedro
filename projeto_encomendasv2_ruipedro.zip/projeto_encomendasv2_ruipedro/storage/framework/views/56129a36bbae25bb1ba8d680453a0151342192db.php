ID:<?php echo e($vendedor->id_vendedor); ?><br>
Designação:<?php echo e($vendedor->nome); ?><br>
Stock:<?php echo e($vendedor->especialidade); ?><br>
Preço:<?php echo e($vendedor->email); ?>


<h2>Produtos</h2>
<?php $__currentLoopData = $vendedor->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($produto->designacao); ?></li>
<h2>Stock</h2>
<li><?php echo e($produto->stock); ?></li>
<h2>Preço</h2>
<li><?php echo e($produto->preco); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\anton\Desktop\Projeto_PSI_Rafael\resources\views/vendedores/show.blade.php ENDPATH**/ ?>