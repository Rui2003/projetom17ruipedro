ID - <u><b><?php echo e($produto->id_produto); ?><br></u></b>
Designação - <b><u><?php echo e($produto->designacao); ?><br></u></b>
Preço - <b><u><?php echo e($produto->preco); ?><br></u></b>
Stock - <b><u><?php echo e($produto->stock); ?><br></u></b>


<h3>Fornecedores</h3>
<?php $__currentLoopData = $produto->fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<b><u><?php echo e($fornecedor->nome); ?><br></b></u>
<b><u><?php echo e($fornecedor->telefone); ?><br></b></u>
<b><u><?php echo e($fornecedor->morada); ?><br></b></u>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/produtos/show.blade.php ENDPATH**/ ?>