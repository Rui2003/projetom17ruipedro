
<?php $__env->startSection('nav'); ?>
<?php $__env->stopSection(); ?>
<br><br><br>
<?php $__env->startSection('final'); ?><ul>
<?php $__currentLoopData = $vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><u>
<a href="<?php echo e(route('vendedores.show', ['id'=>$vendedor->id_vendedor])); ?>">
	<?php echo e($vendedor->nome); ?></a><br></u>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($vendedores->render()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trabalhospsi\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/vendedores/index.blade.php ENDPATH**/ ?>