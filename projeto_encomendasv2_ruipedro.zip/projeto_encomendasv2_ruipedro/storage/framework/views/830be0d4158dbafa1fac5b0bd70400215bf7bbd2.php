<!DOCTYPE html>
<?php echo $__env->yieldContent('inicio'); ?>
<html>

<head>

 <?php echo $__env->yieldContent('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
   <?php echo $__env->yieldContent('img'); ?>
      
</head>

<body>

<?php echo $__env->yieldContent('nav'); ?>
    <nav  class="navbar navbar-expand-md navbar-blue fixed-top bg-dark" >
<a class="navbar-brand" >PSI-Encomendas v2</a>
<button class="navbar-toggler" type="button" data-toggler="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation" >
    <span class="navbar-toggler-icon" ></span>
</button>
<div class="collapse navbar-collapse" id="navbarsExampleDefault" >
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('categorias.index')); ?>">Categorias</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('fornecedores.index')); ?>">Fornecedores</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('produtos.index')); ?>">Produtos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('vendedores.index')); ?>">Vendedores</a>
        </li>
            </li>
        </ul>
    </div>
</nav>
<?php echo $__env->yieldContent('final'); ?>



<hr>
    </div> <!--/container-->
</main> 
<footer class="container">
 
</footer>
</body>
</html>
<?php /**PATH D:\trabalhospsi\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/layout.blade.php ENDPATH**/ ?>