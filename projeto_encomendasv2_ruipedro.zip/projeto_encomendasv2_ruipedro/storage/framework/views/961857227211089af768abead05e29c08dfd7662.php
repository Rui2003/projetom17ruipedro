<ul>
<?php $__currentLoopData = $fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('fornecedores.show', ['id'=>$fornecedor->id_fornecedor])); ?>">
	<?php echo e($fornecedor->nome); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($fornecedores->render()); ?><?php /**PATH C:\Users\anton\Desktop\Projeto_PSI_Rafael\resources\views/fornecedores/index.blade.php ENDPATH**/ ?>