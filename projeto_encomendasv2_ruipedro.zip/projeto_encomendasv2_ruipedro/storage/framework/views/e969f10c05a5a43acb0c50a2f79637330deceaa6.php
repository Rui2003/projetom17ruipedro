ID:<?php echo e($produto->id_produto); ?><br>
Designação:<?php echo e($produto->designacao); ?><br>
Preço:<?php echo e($produto->preco); ?><br>	
Stock:<?php echo e($produto->stock); ?><br>


<h2>Fornecedores</h2>
<?php $__currentLoopData = $produto->fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u><?php echo e($fornecedor->nome); ?></u><br>
<u><?php echo e($fornecedor->telefone); ?></u><br>
<u><?php echo e($fornecedor->morada); ?></u><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\rpedr\OneDrive\Desktop\Projeto_PSI_Rafael\resources\views/produtos/show.blade.php ENDPATH**/ ?>