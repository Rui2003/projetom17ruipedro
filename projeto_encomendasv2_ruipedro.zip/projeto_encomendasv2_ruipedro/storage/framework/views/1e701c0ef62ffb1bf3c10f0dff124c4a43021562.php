ID:<?php echo e($fornecedor->id_fornecedor); ?><br>
Nome:<?php echo e($fornecedor->nome); ?><br>
ID:<?php echo e($fornecedor->id_categoria); ?><br>
Morada:<?php echo e($fornecedor->morada); ?><br>
Telefone:<?php echo e($fornecedor->telefone); ?>


<h2>Vendedores</h2>
<?php $__currentLoopData = $fornecedor->vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($vendedor->nome); ?></li>
<li><?php echo e($vendedor->especialidade); ?></li>
<li><?php echo e($vendedor->email); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h2>Categoria</h2>
<?php $__currentLoopData = $fornecedor->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($categoria->designacao); ?></li>
<br><a href="<?php echo e(route('fornecedores.edit' , ['id' => $fornecedor ->id_fornecedor])); ?>"><b>Editar</b></a>


<br><a href="<?php echo e(route('fornecedores.delete' , ['id' => $fornecedor ->id_fornecedor])); ?>"><b>Eliminar</b></a><br>

<br>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH C:\Users\rpedr\OneDrive\Desktop\ProjetoPSI_ENCOMENDAS-main\ProjetoPSI_ENCOMENDAS-main\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/fornecedores/show.blade.php ENDPATH**/ ?>