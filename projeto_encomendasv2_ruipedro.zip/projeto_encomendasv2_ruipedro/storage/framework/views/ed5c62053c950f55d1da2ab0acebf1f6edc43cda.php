ID:<?php echo e($produto->id_produto); ?><br>
Designação:<?php echo e($produto->designacao); ?><br>
Stock:<?php echo e($produto->stock); ?><br>
Preço:<?php echo e($produto->preco); ?>


<h2>Vendedores</h2>
<?php $__currentLoopData = $produto->vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($vendedor->nome); ?></li>
<li><?php echo e($vendedor->especialidade); ?></li>
<li><?php echo e($vendedor->email); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h2>Fornecedores</h2>
<?php $__currentLoopData = $produto->fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($fornecedor->nome); ?></li>
<li><?php echo e($fornecedor->morada); ?></li>
<li><?php echo e($fornecedor->telefone); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\anton\Desktop\Projeto_PSI_Rafael\resources\views/produtos/show.blade.php ENDPATH**/ ?>