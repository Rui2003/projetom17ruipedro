Nome:<?php echo e($fornecedor->nome); ?><br>
ID:<?php echo e($fornecedor->id_fornecedor); ?><br>
Telefone:<?php echo e($fornecedor->telefone); ?><br>
Morada:<?php echo e($fornecedor->morada); ?><br>

<h2>Vendedores</h2>
<?php $__currentLoopData = $fornecedor->vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u><?php echo e($vendedor->nome); ?></u><br>
<u><?php echo e($vendedor->especialidade); ?></u><br>
<u><?php echo e($vendedor->email); ?></u><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH C:\Users\rpedr\OneDrive\Desktop\Projeto_PSI_Rafael\resources\views/fornecedores/show.blade.php ENDPATH**/ ?>