
<h2>Produtos</h2>
<?php $__currentLoopData = $categoria->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u><?php echo e($produto->designacao); ?></u>
<br>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

Designação:<?php echo e($categoria->designacao); ?><br>
ID:<?php echo e($categoria->id_categoria); ?><br>

<?php /**PATH C:\Users\rpedr\OneDrive\Desktop\Projeto_PSI_Rafael\resources\views/categorias/show.blade.php ENDPATH**/ ?>