
<?php $__env->startSection('nav'); ?>
<?php $__env->stopSection(); ?>
<br><br><br>
<?php $__env->startSection('final'); ?>
<ul>
<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<u>
<a href="<?php echo e(route('categorias.show', ['id'=>$categoria->id_categoria])); ?>">
	<?php echo e($categoria->designacao); ?></a></u>
	<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($categorias->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rpedr\OneDrive\Desktop\Projeto_PSI_Rafael\resources\views/categorias/index.blade.php ENDPATH**/ ?>