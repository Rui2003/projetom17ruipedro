ID:<?php echo e($fornecedor->id_fornecedor); ?><br>
Nome:<?php echo e($fornecedor->nome); ?><br>
Morada:<?php echo e($fornecedor->morada); ?><br>
Telefone:<?php echo e($fornecedor->telefone); ?>


<h2>Vendedores</h2>
<?php $__currentLoopData = $fornecedor->vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($vendedor->nome); ?></li>
<li><?php echo e($vendedor->especialidade); ?></li>
<li><?php echo e($vendedor->email); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h2>Categoria</h2>
<?php $__currentLoopData = $fornecedor->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($categoria->designacao); ?></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\anton\Desktop\Projeto_PSI_Rafael\resources\views/fornecedores/show.blade.php ENDPATH**/ ?>