Nome - <u><b><?php echo e($fornecedor->nome); ?><br></u></b>
ID - <u><b><?php echo e($fornecedor->id_fornecedor); ?><br></u></b>
Telefone - <u><b><?php echo e($fornecedor->telefone); ?><br></u></b>
Morada - <u><b><?php echo e($fornecedor->morada); ?><br></u></b>

<h2>Vendedores</h2>
<?php $__currentLoopData = $fornecedor->vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<b><u><?php echo e($vendedor->nome); ?><br></b></u>
<b><u><?php echo e($vendedor->especialidade); ?><br></b></u>
<b><u><?php echo e($vendedor->email); ?><br></b></u>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH D:\trabalhospsi\projetopsiencomendas-main\projeto_encomendasv2_ruipedro\resources\views/fornecedores/show.blade.php ENDPATH**/ ?>